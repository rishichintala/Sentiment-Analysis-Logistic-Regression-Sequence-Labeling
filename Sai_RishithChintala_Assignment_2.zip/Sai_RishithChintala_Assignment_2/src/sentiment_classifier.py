# write your classifer from scratch here.
# You can use any library you want, but you can't use pre-trained models.
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import re
from sklearn.metrics import classification_report
from datasets import load_dataset

###############################################################################
# 1. Load GloVe Embeddings (reuse your function)
###############################################################################

def load_glove_dict(filepath: str = "../data/glove.6B.50d-subset.txt") -> dict:
    """
    Load the word vectors from a file and return a dictionary mapping words to their vector.
    A special [UNK] token is added (with a zero vector) to handle words not in the embedding file.
    """
    glove_dict = {}
    
    # Read first line to determine embedding dimension.
    with open(filepath, "r", encoding="utf-8") as f:
        first_line = f.readline().strip().split()
        if not first_line or len(first_line) < 2:
            raise ValueError("The embedding file is empty or formatted incorrectly.")
        embed_dim = len(first_line) - 1
    
    # Reserve [UNK] with a zero vector.
    glove_dict["[UNK]"] = np.zeros(embed_dim, dtype=np.float32)
    
    # Read the file and load each word.
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != embed_dim + 1:
                continue
            word = parts[0]
            vector = np.array([float(x) for x in parts[1:]], dtype=np.float32)
            glove_dict[word] = vector
            
    return glove_dict

###############################################################################
# 2. Helper: Convert Sentence to Average Embedding
###############################################################################

def sentence_to_avg_embedding(sentence: str, glove_dict: dict, embed_dim: int) -> np.ndarray:
    """
    Convert a sentence into the average of its word embeddings.
    Uses the provided glove_dict; if a word is missing, uses the [UNK] vector.
    """
    tokens = re.findall(r"\w+", sentence.lower())
    if not tokens:
        return np.zeros(embed_dim, dtype=np.float32)
    
    vectors = []
    for token in tokens:
        if token in glove_dict:
            vectors.append(glove_dict[token])
        else:
            vectors.append(glove_dict["[UNK]"])
    return np.mean(vectors, axis=0)

###############################################################################
# 3. PyTorch Dataset for SST-5
###############################################################################

class SST5Dataset(Dataset):
    """
    PyTorch Dataset for the SST-5 dataset.
    Expects a DataFrame with columns "text" and "label" (numeric: 0-4).
    """
    def __init__(self, df: pd.DataFrame, glove_dict: dict, embed_dim: int):
        self.df = df.reset_index(drop=True)
        self.glove_dict = glove_dict
        self.embed_dim = embed_dim

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        text = row["text"]
        label = row["label"]
        avg_emb = sentence_to_avg_embedding(text, self.glove_dict, self.embed_dim)
        x = torch.tensor(avg_emb, dtype=torch.float)
        y = torch.tensor(label, dtype=torch.long)
        return x, y

###############################################################################
# 4. Define the Deep Neural Network Model
###############################################################################

class DeepAverageNetwork(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int):
        super(DeepAverageNetwork, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, output_dim)
        
    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

###############################################################################
# 5. Training and Evaluation Functions
###############################################################################

def train_model(model, train_loader, val_loader=None, epochs=5, lr=1e-3, device="cpu"):
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    model.to(device)
    
    for epoch in range(epochs):
        model.train()
        total_loss = 0.0
        for x_batch, y_batch in train_loader:
            x_batch = x_batch.to(device)
            y_batch = y_batch.to(device)
            optimizer.zero_grad()
            outputs = model(x_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch+1}/{epochs} - Loss: {avg_loss:.4f}")
        
        if val_loader:
            evaluate_model(model, val_loader, device)
    
    return model

def evaluate_model(model, loader, device="cpu"):
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for x_batch, y_batch in loader:
            x_batch = x_batch.to(device)
            y_batch = y_batch.to(device)
            outputs = model(x_batch)
            preds = torch.argmax(outputs, dim=1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(y_batch.cpu().numpy())
    
    print("Classification Report:")
    print(classification_report(all_labels, all_preds,
                                target_names=["very negative", "negative", "neutral", "positive", "very positive"]))
    return all_preds, all_labels

###############################################################################
# 6. Main: Putting It All Together
###############################################################################

if __name__ == "__main__":
    # 6.1 Load the SST-5 dataset from Hugging Face.
    ds = load_dataset("SetFit/sst5")
    train_df = pd.DataFrame(ds["train"])
    test_df = pd.DataFrame(ds["test"])
    
    # 6.2 Load GloVe embeddings.
    glove_dict = load_glove_dict("../data/glove.6B.300d-subset.txt")
    embed_dim = len(glove_dict["[UNK]"])  # should be 50
    
    # 6.3 Create Dataset and DataLoader objects.
    train_dataset = SST5Dataset(train_df, glove_dict, embed_dim)
    test_dataset = SST5Dataset(test_df, glove_dict, embed_dim)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    
    # 6.4 Instantiate the model.
    model = DeepAverageNetwork(input_dim=embed_dim, hidden_dim=100, output_dim=5)
    
    # 6.5 Train the model.
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    trained_model = train_model(model, train_loader, epochs=50, lr=1e-3, device=device)
    
    # 6.6 Evaluate the model.
    evaluate_model(trained_model, test_loader, device=device)
